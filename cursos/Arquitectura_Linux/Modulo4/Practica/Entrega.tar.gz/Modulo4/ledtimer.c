#include <linux/module.h> /* For manage LKM */
#include <asm-generic/errno.h> /* Macro standar errors */
#include <linux/init.h>
#include <linux/tty.h>      /* For fg_console */
#include <linux/kd.h>       /* For KDSETLED */
#include <linux/vt_kern.h>
#include <linux/proc_fs.h> /* For drive proc entries */
#include <linux/timer.h> /* For drive kernel's timer */

/* Module's information */
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Contador binario modulo 8 con los leds del teclado");
MODULE_AUTHOR("Maximo Zarza");

/* Macros definition */
#define ALL_LEDS_OFF 0
#define MAX_SIZE 6
#define ZERO ALL_LEDS_OFF
#define ONE 1
#define TWO 4
#define THREE 5
#define FOUR 2
#define FIVE 3
#define SIX 6
#define SEVEN 7

/* Global variables definition */
struct tty_driver* kbd_driver = NULL; /* KBD keyboard driver */
static struct proc_dir_entry *proc_entry; /* Proc entry */
struct timer_list _timer; /* Structure that describes the timer led mod 8 */
unsigned int interval = 500; /* Interval in ms. By default is half minute */

/* Get driver handler */
struct tty_driver* get_kbd_driver_handler(void){
  printk(KERN_INFO "ledtimer: loading\n");
  printk(KERN_INFO "ledtimer: fgconsole is %x\n", fg_console);
  return vc_cons[fg_console].d->port.tty->driver;
}

/******************* Leds ********************
***********************************************/
/* Set led state to that specified by mask */
static inline int set_leds(struct tty_driver* handler, unsigned int mask){
  return (handler->ops->ioctl) (vc_cons[fg_console].d->port.tty, KDSETLED,mask);
}


/******************* Timer ********************
***********************************************/
/* Returns next expiration time */
static unsigned long get_expiration(void) {
  return jiffies + msecs_to_jiffies(interval);
}

/* Function invoked when timer expires (fires) */
static void fire_timer(unsigned long data) {
  /* Initializes the mask */
  static unsigned int mask[8] = { ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN };
  
  /* Initializes the counter moment */
  static int count = 0;

  /* Set the leds */
  set_leds(kbd_driver, mask[count]);

  printk("Timer has expired. Count = %i.\n", count);

  /* Gets next counter's value */
  count = (count + 1) % 8;

  /* Re-activate the timer to next_expiration */
  mod_timer( &(_timer), get_expiration());
}
/* Initialize the timer */
void initialize_timer( void ) {
  /* Create timer */
  init_timer(&_timer);
  /* Initialize field */
  _timer.data = 0;
  _timer.function = fire_timer;
  _timer.expires = get_expiration();  /* Activate it */
  /* Activate the timer for the first time */
  add_timer(&_timer);
}
/* Clears the timer */
void cleanup_timer( void ) {
  /* Wait until completion of the timer function (if it's currently running) and delete timer */
  del_timer_sync(&_timer);
}

/******************* /proc ********************
***********************************************/
/* Write callback */
static ssize_t ledtimer_write(struct file *filp, const char __user *buf, size_t len, loff_t *off) {

  char strInput[MAX_SIZE];
  unsigned int new_interval = 0;

  if ((*off) > 0) /* The application can write in this entry just once !! */
    return 0;

  if (len > MAX_SIZE) {
    printk(KERN_INFO "LEDTIMER: To much input\n");
    return -ENOSPC;
  }

  /* Transfer data from user to kernel space */
  if (copy_from_user(&strInput[0], buf, len))
    return -ENOSPC;

  /* Marks the end of the input */
  strInput[len] = '\0';

  /* Converts the input to a decimal */
  if (sscanf(strInput, "%i", &new_interval) != 1) {
    printk(KERN_INFO "LEDTIMER: Incorrect input\n");
    return -EAGAIN;
  }

  /* Modifies expiration */
  interval = new_interval;

  /* Re-activate the timer to next_expiration */
  mod_timer(&(_timer), get_expiration());

  *off+=len; /* Update the file pointer */
  return len;
}
/* Read callback */
static ssize_t ledtimer_read(struct file *filp, char __user *buf, size_t len, loff_t *off) {

  char start[MAX_SIZE];
  char * end = start;
  int nr_bytes;

  if ((*off) > 0) /* Tell the application that there is nothing left to read */
      return 0;

  end += sprintf(end, "%i\n", (int) interval);
  nr_bytes = end - start;

  if (len < nr_bytes)
    return -ENOSPC;

  /* Transfer data from the kernel to userspace */
  if (copy_to_user(buf, start, nr_bytes))
    return -EINVAL;

  (*off)+=len; /* Update the file pointer */

  return nr_bytes;
}

/* Proc entry file operations */
static const struct file_operations proc_entry_fops = {
  .write = ledtimer_write,
  .read = ledtimer_read,
};

/******************* Module funtions ********************
***********************************************/
/* Initalizes the module */
static int __init ledtimer_init(void) {

  /* Local return value */
  int ret = 0;

  /* Gets KBD driver */
  kbd_driver= get_kbd_driver_handler();

  /* Creates the proc entry */
  proc_entry = proc_create( "ledtimer", 0666, NULL, &proc_entry_fops);
  if (proc_entry == NULL) {
    ret = -ENOMEM;
    printk(KERN_INFO "LEDTIMER: Can't create /proc entry\n");
  } else {
      printk(KERN_INFO "LEDTIMER: Module loaded\n");
  }

  /* Initializes the default timer */
  initialize_timer();

  return ret;
}

/* Erases module's resources */
static void __exit ledtimer_exit(void){

  /* Power off the leds */
  set_leds(kbd_driver,ALL_LEDS_OFF);

  /* Removes the proc entry */
  remove_proc_entry("ledtimer", NULL);

  /* Invokes the timer cleanup function */
  cleanup_timer();
}

/* Sets the module's init function */
module_init(ledtimer_init);
/* Sets the modules's exit function */
module_exit(ledtimer_exit);
