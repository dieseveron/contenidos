#include <linux/module.h> 
#include <asm-generic/errno.h>
#include <linux/init.h>
#include <linux/tty.h>      /* For fg_console */
#include <linux/proc_fs.h>
#include <linux/list.h>
#include <linux/vmalloc.h>
#include <linux/spinlock.h>


MODULE_LICENSE("GPL");
MODULE_DESCRIPTION(" Lista enlazada en /proc/modlist");
MODULE_AUTHOR("PEREZ-ZARZA");

#define MAX_SIZE 255

static struct proc_dir_entry *proc_entry;

struct list_head mylist;

typedef struct { 
  int data;
  struct list_head links;
} list_item_t;


DEFINE_SPINLOCK(llave);

void init_list(struct list_head *list)
{
  INIT_LIST_HEAD(list);
}

void clean_list(struct list_head *list)
{
   struct list_head *cur, *aux;
   list_item_t *nodo;
   spin_lock(&llave);
   list_for_each_safe(cur, aux, list)
   {
       nodo = list_entry(cur, list_item_t , links);
       list_del(cur);
       vfree(nodo);
   }
   spin_unlock(&llave);
}

void add_element(struct list_head *list, int element)
{
   list_item_t *nodo = vmalloc(sizeof(list_item_t));
   spin_lock(&llave);
   nodo->data = element;
   list_add_tail(&nodo->links,list);
   spin_lock(&llave);
}

void remove_element(struct list_head *list, int element)
{
   struct list_head *cur, *aux;
   list_item_t *nodo;
   spin_lock(&llave);
   list_for_each_safe(cur, aux, list)
   {
	nodo = list_entry(cur, list_item_t , links); 
        if (nodo->data == element)
	{
           list_del(cur);
           vfree(nodo);
	}    
   }
   spin_unlock(&llave);
}

void print_list(struct list_head * list)
{
   struct list_head *cur;
   list_item_t *nodo;
   printk(KERN_INFO "INICIO LISTA \n");
   list_for_each(cur, list)
   {
        nodo = list_entry(cur, list_item_t , links);
        printk(KERN_INFO "%d\n",nodo->data);
   }
   printk(KERN_INFO "MODLIS: FIN  LISTA \n");
} 



static ssize_t modlist_write(struct file *filp, const char __user *buf, size_t len, loff_t *off) {
  
  char str[MAX_SIZE];
  int val; 
 
  if ((*off) > 0) /* The application can write in this entry just once !! */
    return 0;
  if (len > MAX_SIZE - 1) {
    printk(KERN_INFO "MODLIST: Incorrect command \n");
    return -ENOSPC;
  }
  if (copy_from_user( &str[0], buf, len ))  
    return -EFAULT;
  
  str[len] = '\0';

  if(sscanf(str,"add %i",&val)==1) 
  {
     add_element(&mylist,val);
  } else if (sscanf(str,"remove %i",&val)==1) {
     remove_element(&mylist,val);    
  } else if (strcmp(str,"cleanup\n")==0) {
     clean_list(&mylist);	
  }
  *off+=len;            /* Update the file pointer */
  return len;
}


static ssize_t modlist_read(struct file *filp, char __user *buf, size_t len, loff_t *off) {

  char str[MAX_SIZE];
  char * dst = str;
  int cant = 0;
  int aux = 0;
  struct list_head *cur = NULL;
  list_item_t *nodo; 
  
  if ((*off) > 0)
    return 0;
  
  spin_lock(&llave);
  list_for_each(cur, &mylist)
  {     
        nodo = list_entry(cur, list_item_t , links);
	char auxBuf[MAX_SIZE];  
        aux = sprintf(auxBuf, "%i\n",nodo->data);
        
	if(aux + dst - str > MAX_SIZE) break;
	dst += sprintf(dst, "%s", auxBuf);
  }
  spin_unlock(&llave);

  cant = dst - str;  

  if (copy_to_user(buf, str, cant))
    return -EFAULT;

  *off+=cant;            /* Update the file pointer */
  return cant;
}


static const struct file_operations proc_entry_fops = {
    .write = modlist_write,    
    .read  = modlist_read,
};

static int __init modlist_init(void)
{	
  int ret = 0;
  proc_entry = proc_create( "modlist", 0666, NULL, &proc_entry_fops);
  if (proc_entry == NULL) {
    ret = -ENOMEM;
    printk(KERN_INFO "MODLIST: Can't create /proc entry\n");
  } else {
      printk(KERN_INFO "MODLIST: Module loaded\n");
  }
  init_list(&mylist);
  return ret;
}

static void __exit modlist_exit(void){
   clean_list(&mylist);
   remove_proc_entry("modlist", NULL);
}

module_init(modlist_init);
module_exit(modlist_exit);

