#!/bin/bash

for i in `seq 1 500`; do
  echo "add $i" > /proc/modlist  
  echo "Se agrego el $i"
  sleep 1
done
