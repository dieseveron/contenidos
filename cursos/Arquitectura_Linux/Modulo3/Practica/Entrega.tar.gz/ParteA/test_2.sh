#!/bin/bash

for i in `seq 1 500`; do
  sleep 3
  echo "remove $i" > /proc/modlist  
  echo "Se emilino el $i"
done
