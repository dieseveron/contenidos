#include "cbuffer.h"
#ifdef __KERNEL__
#include <linux/vmalloc.h> /* vmalloc()/vfree()*/
#include <asm/string.h> /* memcpy() */
#else
#include <stdlib.h>
#include <string.h>
#endif

#ifndef NULL
#define NULL 0
#endif

/* Create cbuffer */
cbuffer_t* create_cbuffer_t (unsigned int max_size)
{
#ifdef __KERNEL__
    cbuffer_t *cbuffer= (cbuffer_t *)vmalloc(sizeof(cbuffer_t));
#else
    cbuffer_t *cbuffer= (cbuffer_t *)malloc(sizeof(cbuffer_t));
#endif
    if (cbuffer == NULL) {
        return NULL;
    }
    cbuffer->size=0;
    cbuffer->head=0;
    cbuffer->max_size=max_size;

    /* Stores bytes */
#ifdef __KERNEL__
    cbuffer->data=vmalloc(sizeof(int)*max_size);
#else
    cbuffer->data=malloc(sizeof(int)*max_size);
#endif
    if ( cbuffer->data == NULL) {
#ifdef __KERNEL__
        vfree(cbuffer->data);
#else
        free(cbuffer->data);
#endif
        return NULL;
    }
    return cbuffer;
}

/* Release memory from circular buffer  */
void destroy_cbuffer_t ( cbuffer_t* cbuffer )
{
    cbuffer->size=0;
    cbuffer->head=0;
    cbuffer->max_size=0;
#ifdef __KERNEL__
    vfree(cbuffer->data);
    vfree(cbuffer);
#else
    free(cbuffer->data);
    free(cbuffer);
#endif
}

/* Returns the number of elements in the buffer */
int size_cbuffer_t ( cbuffer_t* cbuffer )
{
    return cbuffer->size ;
}

int nr_gaps_cbuffer_t ( cbuffer_t* cbuffer )
{
    return cbuffer->max_size-cbuffer->size;
}

/* Return a non-zero value when buffer is full */
int is_full_cbuffer_t ( cbuffer_t* cbuffer )
{
    return ( cbuffer->size == cbuffer->max_size ) ;
}

/* Return a non-zero value when buffer is empty */
int is_empty_cbuffer_t ( cbuffer_t* cbuffer )
{
    return ( cbuffer->size == 0 ) ;
}


/* Inserts an item at the end of the buffer */
void insert_cbuffer_t ( cbuffer_t* cbuffer, int new_item )
{
    unsigned int pos=0;
    /* The buffer is full */
    if ( cbuffer->size == cbuffer->max_size ) {
        /* Overwriting head position */
        cbuffer->data[cbuffer->head]=new_item;
        /* Now head position must be the next one*/
        if ( cbuffer->size !=0 )
            cbuffer->head= ( cbuffer->head+1 ) % cbuffer->max_size;
        /* Size remains constant*/
    } else {
        if ( cbuffer->max_size!=0 )
            pos= ( cbuffer->head+cbuffer->size ) % cbuffer->max_size;
        cbuffer->data[pos]=new_item;
        cbuffer->size++;
    }
}

/* Remove first element in the buffer */
int remove_cbuffer_t ( cbuffer_t* cbuffer)
{
    int ret=-1;

    if ( cbuffer->size !=0 ) {
        ret=cbuffer->data[cbuffer->head];
        cbuffer->head= ( cbuffer->head+1 ) % cbuffer->max_size;
        cbuffer->size--;
    }

    return ret;
}

/* Removes all items in the buffer */
void clear_cbuffer_t (cbuffer_t* cbuffer)
{
    cbuffer->size = 0;
    cbuffer->head = 0;
}
