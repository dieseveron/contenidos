NOMBRE="Fulano De Tal"
facultad=Informatica
carrera_1="Licenciatura en Sistemas"
carrera_2="Licenciatura en Informatica"
echo El alumno $NOMBRE de la Facultad de $facultad cursa $carrera_1 y $carrera_2
#  imprime:
#  El alumno Fulano De Tal de la Facultad de 
#  Informática cursa Licenciatura en Sistemas
#  y Licenciatura en Informatica