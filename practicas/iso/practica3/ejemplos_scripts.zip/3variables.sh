#!/bin/bash

nombre=Carlos
echo "Hola $nombre" # Hola Carlos
echo Hola ${nombre} # Hola Carlos

nombre=5
echo "Hola $nombre" # Hola 5