#!/bin/bash

# Si la primer línea de mi script comienza con  la cadena #! se interpretará como el path
# al intérprete a utilizar (podría ser python, perl, php, etc...)

# Ahora el script en sí
echo "Hola mundo"