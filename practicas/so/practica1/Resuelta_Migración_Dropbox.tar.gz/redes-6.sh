#!/bin/bash

if [ $# -eq 0 ]; then
  echo "Debe especificar cliente (c) y su nickname o servidor (s)"
  exit 1
fi

PORT=2015
IP=127.0.0.1

function _servidor() {
  while :; do
    msg=`nc -l $IP $PORT` 
    echo "$(date), $msg"
  done
}

function _cliente() {
  while :; do
    read msg
    echo -e "$1 says:\n  $msg" | nc $IP $PORT
  done
}

if [ $1 = s ]; then
  _servidor
elif [ $1 = c ]; then
  _cliente $2
else
  echo "Parámetro erróneo: $1"
  exit 2
fi
