PORT=9876

# En una terminal ejecutar
nc -l 127.0.0.1 $PORT

# Luego, en otra terminal ejecutar
nc 127.0.0.1 $PORT

# Después podemos escribir en la segunda terminal y en cada \n
# el mismo texto aparecerá en la primera terminal
