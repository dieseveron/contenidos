#!/bin/bash

# 6. Realice un script que copie todos los archivos del directorio home
# del usuario que lo ejecuta, a un subdirectorio del mismo llamado backup
# cambiándoles el nombre para que esté en mayúsculas. No se deben procesar 
# los subdirectorios del home del usuario, únicamente los archivos ubicados
# directamente en este. Si el directorio backup existe al iniciar el script,
# el contenido del mismo debe borrarse antes de copiar los archivos.

DIRECTORIO=/tmp/repaso-6

function _preparar_ejemplo() {
  mkdir -p $DIRECTORIO
  rm -rf $DIRECTORIO/*
  pushd $DIRECTORIO
  mkdir debe-ser-ignorado
  touch un-archivo.txt otro_archivo.doc una_foto.jpg video.avi
  popd
}

function imprimir_estructura() {
  if [ -z "`which tree`" ]; then
    ls -R
  else
    tree
  fi
}

_preparar_ejemplo
cd $DIRECTORIO # Debiera ser cd $HOME

echo "- ANTES:"
imprimir_estructura

if [ -d backup ]; then
  rm -rf backup
fi

mkdir backup

for archivo in `find * -maxdepth 0 -type f`; do
  nuevo_nombre="`echo $archivo | tr a-z A-Z`" 
  echo $archivo => backup/$nuevo_nombre
done

echo "- DESPUES:"
imprimir_estructura
