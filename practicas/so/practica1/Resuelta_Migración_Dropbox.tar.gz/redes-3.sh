#!/bin/bash

# 3. Desarrolle un script que reciba en su entrada estándar una
# lista de hosts e imprima en su salida estándar únicamente 
# aquellos que tienen el puerto 80 abierto.

# Invocar pasando por entrada estándar los hosts:
# $ echo www.google.com www.unlp.edu.ar | ./redes-3.sh

TIMEOUT=1
PORT=80

read hosts

for host in $hosts; do
  nc -w $TIMEOUT $host $PORT
  if [ $? -eq 0 ]; then
    echo $host
  fi
done
