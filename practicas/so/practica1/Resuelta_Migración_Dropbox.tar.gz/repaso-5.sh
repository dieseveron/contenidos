#!/bin/bash

# 5. Escriba un script que liste en orden alfabético inverso el contenido del directorio actual.

ls -r
