#!/bin/bash

# En primer lugar crea un named pipe.
# La secuencia producida es la siguiente:
#	La entrada recibida desde la red, en el lado servidor, es escrita en el named pipe.
#	El named pipe es leido por el comando `cat` y su contenido es enviado al comando `sh`.
#	El comando `sh` precesa la entrada recibida desde el cliente y escribe el resultado en `nc`.
#	Netcat envia el resultado sobre la red hacia el cliente.

#En una terminal ejecute
mkfifo /tmp/f
cat /tmp/f | /bin/sh -i 2>&1 | nc -l 127.0.0.1 1234 > /tmp/f

#En otra terminal ejecute
nc localhost 1234
#Automáticamente obtendra el promp ($), por lo que podra interactuar con el servidor ingresando comandos.

