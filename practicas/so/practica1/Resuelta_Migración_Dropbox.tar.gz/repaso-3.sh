#!/bin/bash

# 3. Desarrolle un script que guarde en un arreglo todos los archivos del directorio actual
# (incluyendo sus subdirectorios) para los cuales el usuario que ejecuta el script tiene
# permisos de ejecución. Luego, implemente las siguientes funciones:
#   (a) cantidad: Imprime la cantidad de archivos que se encontraron
#   (b) archivos: Imprime los nombres de los archivos encontrados en orden alfabético

archivos=(`find . -maxdepth 1 -type f -executable`)

function cantidad() {
  echo ${#archivos[*]}
}

function archivos() {
  echo ${archivos[*]}
}

echo "Invocando cantidad:"
cantidad

echo "Invocando archivos:"
archivos
