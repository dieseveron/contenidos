#!/bin/bash

# 4. Desarrolle un script que reciba en su entrada estándar 
# una lista de hosts con el puerto 80 abierto y, para cada uno,
# realice un requerimiento HTTP GET a la URI raíz y devuelva
# el valor del campo Content-Length de la respuesta

PORT=80

read hosts

for host in $hosts; do
  echo $host: `printf "GET / HTTP/1.0\r\n\r\n" | nc $host $PORT | wc -c`
done
