#!/bin/bash

# 1. Relice un script que guarde en el archivo /tmp/usuarios los nombres
# de los usuarios del sistema cuyo UID sea mayor a 1000.

for user_uid in `cat /etc/passwd | cut -d: -f1,3`; do 
  if [ `echo $user_uid | cut -d: -f2` -gt 1000 ]; then
    echo $user_uid | cut -d: -f1
  fi
done 
