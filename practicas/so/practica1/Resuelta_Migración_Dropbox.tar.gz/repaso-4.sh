#!/bin/bash

# 4. Se le ha encomendado organizar las fotos (en formato jpg) de todos los eventos
# de los que su empresa ha participado en el último año, los cuales se encuentran
# organizados en directorios con el nombre del evento. Para facilitar su búsqueda 
# posterior, los archivos deben tener nombres que sigan el siguiente patrón: EVENTO-N.jpg, donde:
#   EVENTO es el nombre del evento (el del directorio que se está procesando)
#   N es un índice de foto, comenzando en 1

DIRECTORIO=/tmp/repaso-4

function _preparar_ejemplo() {
  mkdir -p $DIRECTORIO
  rm -rf $DIRECTORIO/*
  pushd $DIRECTORIO
  mkdir bashconf15 jsconf-14 oktoberfest-14
  touch bashconf15/DSC0105{0..4}.jpg \
        jsconf-14/DSC0123{0,1,2,5,6}.jpg \
        oktoberfest-14/DSC02229.jpg oktoberfest-14/DSC0223{0..2}.jpg
  popd
}

function imprimir_estructura() {
  if [ -z "`which tree`" ]; then
    ls -R
  else
    tree
  fi
}

_preparar_ejemplo
cd $DIRECTORIO

echo "- ANTES:"
imprimir_estructura

for evento in `find * -maxdepth 0 -type d`; do
  i=0
  cd $evento
  echo Procesando $evento...
  for foto in *.jpg; do
    let i++
    mv $foto $evento-$i.jpg
  done
  cd ..
done

echo "- DESPUES:"
imprimir_estructura
