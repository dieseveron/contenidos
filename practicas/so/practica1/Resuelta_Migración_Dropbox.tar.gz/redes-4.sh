#!/bin/bash

for host in $*
do

	echo -n $host:
	printf "GET / HTTP/1.0\r\n\r\n" | nc $host 80 | grep Content-Length | cut -d: -f2

done
