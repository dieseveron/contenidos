#!/bin/bash

# 2. Implemente un script que reciba como parámetro el nombre de un proceso
# e informe cada 15 segundos cuántas instancias de ese proceso están en ejecución.

if [ $# -ne 1 ]; then
  echo "Debe especificar el nombe del proceso a buscar"
  exit 1
fi

while :; do
  echo El proceso $1 está corriendo `ps aux | grep -w $1 | wc -l` instancias
  sleep 15
done
