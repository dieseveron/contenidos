#!/bin/bash

# 7. Un escritor tiene organizados los capítulos de su próximo libro en
# distintos archivos de texto plano en un mismo directorio, y le ha 
# solicitado ayuda para concatenar el contenido de cada uno de ellos en
# un único archivo final llamado libro.txt, de modo tal que éste último
# contenga el texto de todos los otros archivos, uno luego del otro.
# Puede asumir que los archivos de los capítulos tienen nombres
# alfabéticamente ordenados

DIRECTORIO=/tmp/repaso-7

function _preparar_ejemplo() {
  mkdir -p $DIRECTORIO
  rm -rf $DIRECTORIO/*
  pushd $DIRECTORIO
  mkdir debe-ser-ignorado
  for n in `seq -f "%02g" 1 50`; do
    echo "Capitulo $n" > capitulo-$n.txt
    echo "Sin tele y sin cerveza Homero pierde la cabeza" >> capitulo-$n.txt
  done
  popd
}

function imprimir_estructura() {
  if [ -z "`which tree`" ]; then
    ls -R
  else
    tree
  fi
}

_preparar_ejemplo
cd $DIRECTORIO

echo "- ANTES:"
imprimir_estructura

rm -f libro.txt # Para no incluirlo en la concatenación
cat *.txt > libro.txt

echo "- DESPUES:"
imprimir_estructura
less libro.txt
