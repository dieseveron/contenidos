#include <linux/kobject.h>
#include <linux/sysfs.h>
#include <linux/module.h>
#include <linux/init.h>

static int unlp;

/*
 * Función invocada cuando se lee el atributo "unlp"
 */
static ssize_t unlp_show(struct kobject *kobj, struct kobj_attribute *attr,
			char *buf)
{
	return sprintf(buf, "%d\n", ++unlp);
}

/*
 * Función invocada cuando se escribe el atributo "unlp"
 */
static ssize_t unlp_store(struct kobject *kobj, struct kobj_attribute *attr,
			 const char *buf, size_t count)
{
	sscanf(buf, "%du", &unlp);
	return count;
}

static struct kobj_attribute unlp_attribute =
	__ATTR(unlp, 0666, unlp_show, unlp_store);

static struct kobject *my_kobject;

static int __init example_init(void)
{
	int ret;

	/*
	 * Crea un kobject con nombre "unlp_sistemas_operativos" 
	 * y lo ubica en /sys/kernel
	 */
	my_kobject = kobject_create_and_add("unlp_sistemas_operativos", kernel_kobj);
	if (!my_kobject)
		return -ENOMEM;

	/* Crea el atributo asociado al kobject */
	ret = sysfs_create_file(my_kobject, &unlp_attribute.attr);
	if (ret)
		kobject_put(my_kobject);

	return ret;
}

static void __exit example_exit(void)
{
	kobject_put(my_kobject);
}

module_init(example_init);
module_exit(example_exit);
MODULE_LICENSE("GPL");
